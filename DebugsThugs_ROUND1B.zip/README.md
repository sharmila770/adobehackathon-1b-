# Adobe PDF CLI Tool - Round 1B (Persona-Based Content Extraction)

A command-line Python tool for extracting persona-relevant content from PDF documents using semantic similarity.

## Features

- **Persona-Based Extraction**: Reads persona from `persona.txt` and finds relevant content
- **Semantic Similarity**: Uses sentence-transformers (with TF-IDF fallback) for content matching
- **Top-K Selection**: Returns top 5 most relevant paragraphs per PDF
- **Batch Processing**: Processes multiple PDF files from `/app/input/`
- **JSON Output**: Structured output saved as `{filename}.json` in `/app/output/`
- **Offline Ready**: Pre-downloads models for complete offline execution
- **Docker Compatible**: Runs on `linux/amd64` without internet

## Requirements

- Python 3.11+
- PyMuPDF (fitz) 1.23.14
- sentence-transformers 2.2.2 (with scikit-learn fallback)
- scikit-learn 1.3.2
- numpy 1.24.4

## Installation

### Docker (Recommended)
```bash
# Build the Docker image
docker build -t adobe-pdf-cli-round1b .

# Run with mounted volumes
docker run -v /path/to/input:/app/input -v /path/to/output:/app/output adobe-pdf-cli-round1b
```

### Local Development
```bash
pip install -r requirements.txt
```

## Usage

### Directory Structure
```
/app/
├── input/
│   ├── persona.txt     # Persona description
│   ├── document1.pdf   # PDF files to process
│   └── document2.pdf
├── output/             # JSON results will be saved here
└── main.py            # CLI tool
```

### Input Files
1. **persona.txt**: Contains the persona description (required)
   ```
   A data scientist interested in machine learning algorithms and statistical analysis.
   ```

2. **PDF files**: Documents to extract relevant content from

### Running the Tool
```bash
python main.py
```

### Output Format
```json
{
  "pdf": "document1.pdf",
  "persona": "A data scientist interested in machine learning...",
  "matched_sections": [
    {
      "text": "Machine learning algorithms have revolutionized...",
      "page": 3,
      "score": 0.847
    },
    {
      "text": "Statistical analysis provides the foundation...",
      "page": 7,
      "score": 0.723
    }
  ]
}
```

## Algorithm Details

### Similarity Calculation
1. **Primary Method**: sentence-transformers with 'all-MiniLM-L6-v2' model
2. **Fallback Method**: TF-IDF vectorization + cosine similarity

### Content Processing
1. **Paragraph Extraction**: Extracts text blocks from PDF pages
2. **Text Cleaning**: Normalizes whitespace and removes special characters
3. **Filtering**: Removes paragraphs that are too short (<50 chars) or too long (>2000 chars)
4. **Scoring**: Calculates semantic similarity between persona and each paragraph
5. **Selection**: Returns top 5 highest-scoring paragraphs

### Performance Optimizations
- Efficient text block processing
- Batch encoding for similarity calculations
- Memory-optimized paragraph filtering
- Pre-downloaded models for offline execution

## Docker Offline Support

The Dockerfile includes:
- Pre-installation of all system dependencies
- Pre-download of sentence-transformers model
- No internet required during runtime
- Platform-specific build for `linux/amd64`

## Error Handling

- Graceful fallback from sentence-transformers to TF-IDF
- Robust PDF parsing with error recovery
- Validation of required input files
- Detailed error messages and logging
