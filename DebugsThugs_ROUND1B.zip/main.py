#!/usr/bin/env python3
"""
Adobe "Connecting the Dots" Challenge - Round 1B
CLI tool for extracting persona-relevant content from PDF documents.
"""

import os
import json
import sys
import time
import re
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import fitz  # PyMuPDF

# Try to import sentence-transformers, fallback to TF-IDF if not available
try:
    from sentence_transformers import SentenceTransformer
    from sklearn.metrics.pairwise import cosine_similarity
    import numpy as np
    SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    SENTENCE_TRANSFORMERS_AVAILABLE = False
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    import numpy as np


class PersonaContentExtractor:
    """Extracts persona-relevant content from PDF documents using semantic similarity."""
    
    def __init__(self):
        self.input_dir = Path("/app/input")
        self.output_dir = Path("/app/output")
        self.persona_text = ""
        self.similarity_model = None
        self.vectorizer = None
        
    def ensure_directories(self):
        """Ensure input and output directories exist."""
        self.output_dir.mkdir(parents=True, exist_ok=True)
        if not self.input_dir.exists():
            print(f"Error: Input directory {self.input_dir} does not exist")
            sys.exit(1)
    
    def load_persona(self) -> str:
        """Load persona text from persona.txt file."""
        persona_file = self.input_dir / "persona.txt"
        
        if not persona_file.exists():
            print(f"Error: persona.txt not found in {self.input_dir}")
            sys.exit(1)
        
        try:
            with open(persona_file, 'r', encoding='utf-8') as f:
                persona_text = f.read().strip()
            
            if not persona_text:
                print("Error: persona.txt is empty")
                sys.exit(1)
            
            print(f"Loaded persona: {persona_text[:100]}{'...' if len(persona_text) > 100 else ''}")
            return persona_text
            
        except Exception as e:
            print(f"Error reading persona.txt: {str(e)}")
            sys.exit(1)
    
    def initialize_similarity_model(self):
        """Initialize the similarity model (sentence-transformers or TF-IDF fallback)."""
        if SENTENCE_TRANSFORMERS_AVAILABLE:
            try:
                print("Initializing sentence-transformers model...")
                self.similarity_model = SentenceTransformer('all-MiniLM-L6-v2')
                print("Using sentence-transformers for semantic similarity")
                return
            except Exception as e:
                print(f"Failed to load sentence-transformers: {e}")
                print("Falling back to TF-IDF...")
        
        # Fallback to TF-IDF
        print("Using TF-IDF + cosine similarity as fallback")
        self.vectorizer = TfidfVectorizer(
            max_features=5000,
            stop_words='english',
            ngram_range=(1, 2),
            min_df=1,
            max_df=0.95
        )
    
    def clean_text(self, text: str) -> str:
        """Clean and normalize text for processing."""
        # Remove extra whitespace and newlines
        text = re.sub(r'\s+', ' ', text)
        # Remove special characters but keep basic punctuation
        text = re.sub(r'[^\w\s.,!?;:-]', '', text)
        return text.strip()
    
    def extract_paragraphs(self, doc: fitz.Document) -> List[Dict]:
        """Extract paragraphs from PDF document with page numbers."""
        paragraphs = []
        
        for page_num in range(len(doc)):
            page = doc[page_num]
            blocks = page.get_text("dict")["blocks"]
            
            for block in blocks:
                if "lines" not in block:
                    continue
                
                # Extract text from block
                block_text = ""
                for line in block["lines"]:
                    if "spans" in line:
                        line_text = "".join(span.get("text", "") for span in line["spans"])
                        block_text += line_text + " "
                
                block_text = self.clean_text(block_text)
                
                # Filter paragraphs by length and content
                if (len(block_text) >= 50 and  # Minimum length
                    len(block_text) <= 2000 and  # Maximum length
                    len(block_text.split()) >= 10):  # Minimum word count
                    
                    paragraphs.append({
                        "text": block_text,
                        "page": page_num + 1
                    })
        
        return paragraphs
    
    def calculate_similarity_sentence_transformers(self, persona: str, paragraphs: List[Dict]) -> List[Dict]:
        """Calculate similarity using sentence-transformers."""
        if not paragraphs:
            return []
        
        # Encode persona and paragraphs
        persona_embedding = self.similarity_model.encode([persona])
        paragraph_texts = [p["text"] for p in paragraphs]
        paragraph_embeddings = self.similarity_model.encode(paragraph_texts)
        
        # Calculate cosine similarities
        similarities = cosine_similarity(persona_embedding, paragraph_embeddings)[0]
        
        # Add similarity scores to paragraphs
        for i, paragraph in enumerate(paragraphs):
            paragraph["score"] = float(similarities[i])
        
        return paragraphs
    
    def calculate_similarity_tfidf(self, persona: str, paragraphs: List[Dict]) -> List[Dict]:
        """Calculate similarity using TF-IDF + cosine similarity."""
        if not paragraphs:
            return []
        
        # Prepare texts for vectorization
        texts = [persona] + [p["text"] for p in paragraphs]
        
        try:
            # Fit TF-IDF vectorizer and transform texts
            tfidf_matrix = self.vectorizer.fit_transform(texts)
            
            # Calculate cosine similarities between persona and paragraphs
            persona_vector = tfidf_matrix[0:1]  # First row is persona
            paragraph_vectors = tfidf_matrix[1:]  # Rest are paragraphs
            
            similarities = cosine_similarity(persona_vector, paragraph_vectors)[0]
            
            # Add similarity scores to paragraphs
            for i, paragraph in enumerate(paragraphs):
                paragraph["score"] = float(similarities[i])
            
        except Exception as e:
            print(f"Error in TF-IDF similarity calculation: {e}")
            # Fallback: assign random scores
            for paragraph in paragraphs:
                paragraph["score"] = 0.1
        
        return paragraphs
    
    def find_relevant_content(self, persona: str, paragraphs: List[Dict], top_k: int = 5) -> List[Dict]:
        """Find the most relevant paragraphs for the given persona."""
        if not paragraphs:
            return []
        
        # Calculate similarities based on available method
        if self.similarity_model is not None:
            scored_paragraphs = self.calculate_similarity_sentence_transformers(persona, paragraphs)
        else:
            scored_paragraphs = self.calculate_similarity_tfidf(persona, paragraphs)
        
        # Sort by similarity score (descending) and return top K
        scored_paragraphs.sort(key=lambda x: x["score"], reverse=True)
        
        return scored_paragraphs[:top_k]
    
    def process_pdf(self, pdf_path: Path, persona: str) -> Dict:
        """Process a single PDF file and extract persona-relevant content."""
        try:
            doc = fitz.open(str(pdf_path))
            
            # Extract paragraphs
            paragraphs = self.extract_paragraphs(doc)
            
            # Find relevant content
            relevant_sections = self.find_relevant_content(persona, paragraphs)
            
            doc.close()
            
            # Format output
            matched_sections = []
            for section in relevant_sections:
                matched_sections.append({
                    "text": section["text"],
                    "page": section["page"],
                    "score": round(section["score"], 3)
                })
            
            return {
                "pdf": pdf_path.name,
                "persona": persona,
                "matched_sections": matched_sections
            }
            
        except Exception as e:
            print(f"Error processing {pdf_path}: {str(e)}")
            return {
                "pdf": pdf_path.name,
                "persona": persona,
                "matched_sections": []
            }
    
    def process_all_pdfs(self):
        """Process all PDF files in the input directory."""
        self.ensure_directories()
        
        # Load persona
        persona = self.load_persona()
        
        # Initialize similarity model
        self.initialize_similarity_model()
        
        # Find PDF files
        pdf_files = list(self.input_dir.glob("*.pdf"))
        
        if not pdf_files:
            print(f"No PDF files found in {self.input_dir}")
            return
        
        print(f"Found {len(pdf_files)} PDF files to process")
        
        for pdf_file in pdf_files:
            start_time = time.time()
            print(f"Processing: {pdf_file.name}")
            
            # Process PDF
            result = self.process_pdf(pdf_file, persona)
            
            # Save result as JSON
            output_filename = f"{pdf_file.stem}.json"
            output_path = self.output_dir / output_filename
            
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(result, f, indent=2, ensure_ascii=False)
            
            processing_time = time.time() - start_time
            print(f"Completed: {pdf_file.name} -> {output_filename} ({processing_time:.2f}s)")
            print(f"  Relevant sections found: {len(result['matched_sections'])}")
            
            # Show top match if available
            if result['matched_sections']:
                top_match = result['matched_sections'][0]
                preview = top_match['text'][:100] + '...' if len(top_match['text']) > 100 else top_match['text']
                print(f"  Top match (score: {top_match['score']}): {preview}")


def main():
    """Main entry point for the CLI tool."""
    print("Adobe PDF CLI Tool - Connecting the Dots Challenge (Round 1B)")
    print("=" * 60)
    
    extractor = PersonaContentExtractor()
    
    try:
        extractor.process_all_pdfs()
        print("\nProcessing completed successfully!")
    except KeyboardInterrupt:
        print("\nProcessing interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\nError: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()
