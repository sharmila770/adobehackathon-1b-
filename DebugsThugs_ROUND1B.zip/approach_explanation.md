# Round 1B — Approach Explanation

## 🧠 Objective

To build a semantic filtering layer on top of the Round 1A pipeline that intelligently selects content from PDF documents most relevant to a given persona.

## 🧩 Core Logic

1. **Input**:
   - A `persona.txt` file containing a textual description of the target audience or user interest.
   - PDF documents in the `/input` folder.

2. **Text Extraction**:
   - Each PDF is parsed using PyMuPDF to extract paragraphs and (if found) associated headings and page numbers.

3. **Semantic Similarity Computation**:
   - The persona text is compared to each paragraph using:
     - ✅ `sentence-transformers` (`all-MiniLM-L6-v2`) as the primary method.
     - 🔄 TF-IDF + cosine similarity as a fallback (used if sentence-transformers is not available).

4. **Ranking and Selection**:
   - Similarity scores are computed and paragraphs are ranked.
   - The top 5 semantically relevant segments are selected per document.

5. **Output**:
   - A structured JSON is created for each PDF, listing:
     - Page number
     - Heading (if available)
     - Paragraph text

## 🔍 Libraries Used

- `PyMuPDF` for text extraction
- `sentence-transformers` for semantic encoding
- `scikit-learn` for TF-IDF and cosine similarity fallback
- `numpy` and `torch` for model compatibility

## 💻 Offline Execution

- All models are installed and pre-loaded during Docker build to allow offline execution.
- Docker ensures reproducibility and ease of testing across platforms.

## ✅ Highlights

- Hybrid model design ensures graceful fallback.
- Efficient ranking with minimal compute load.
- Flexible, language-agnostic, and scalable to multiple PDFs and personas.
