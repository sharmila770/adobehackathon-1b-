#!/usr/bin/env python3
"""
Local testing script for the Adobe PDF CLI tool Round 1B.
Creates test directories and runs the tool locally.
"""

import os
import sys
import tempfile
import shutil
from pathlib import Path

# Add current directory to path to import main
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from main import PersonaContentExtractor


def create_test_environment():
    """Create a temporary test environment with input/output directories."""
    # Create temporary directory
    temp_dir = Path(tempfile.mkdtemp(prefix="adobe_pdf_round1b_test_"))
    
    # Create input and output directories
    input_dir = temp_dir / "input"
    output_dir = temp_dir / "output"
    
    input_dir.mkdir(exist_ok=True)
    output_dir.mkdir(exist_ok=True)
    
    print(f"Created test environment at: {temp_dir}")
    print(f"Input directory: {input_dir}")
    print(f"Output directory: {output_dir}")
    
    return temp_dir, input_dir, output_dir


def create_sample_persona(input_dir):
    """Create a sample persona.txt file."""
    persona_content = """A data scientist interested in machine learning algorithms, statistical analysis, and artificial intelligence applications in business."""
    
    persona_file = input_dir / "persona.txt"
    with open(persona_file, 'w', encoding='utf-8') as f:
        f.write(persona_content)
    
    print(f"Created sample persona.txt: {persona_content}")
    return persona_content


def test_with_local_dirs():
    """Test the PDF processor with local directories."""
    temp_dir, input_dir, output_dir = create_test_environment()
    
    try:
        # Create sample persona
        persona_content = create_sample_persona(input_dir)
        
        # Create a custom processor with local directories
        class LocalPersonaContentExtractor(PersonaContentExtractor):
            def __init__(self, input_path, output_path):
                self.input_dir = Path(input_path)
                self.output_dir = Path(output_path)
                self.persona_text = ""
                self.similarity_model = None
                self.vectorizer = None
        
        extractor = LocalPersonaContentExtractor(input_dir, output_dir)
        
        print("\nPlace your test PDF files in the input directory:")
        print(f"  {input_dir}")
        print("\nThe persona.txt file has been created with sample content.")
        print("Press Enter to continue with processing...")
        input()
        
        # Process PDFs
        extractor.process_all_pdfs()
        
        print(f"\nResults saved to: {output_dir}")
        print("Contents:")
        for file in output_dir.glob("*.json"):
            print(f"  - {file.name}")
            
            # Show sample output
            with open(file, 'r', encoding='utf-8') as f:
                result = json.load(f)
                print(f"    PDF: {result['pdf']}")
                print(f"    Matched sections: {len(result['matched_sections'])}")
                if result['matched_sections']:
                    top_match = result['matched_sections'][0]
                    preview = top_match['text'][:100] + '...' if len(top_match['text']) > 100 else top_match['text']
                    print(f"    Top match (score: {top_match['score']}): {preview}")
        
        print(f"\nTest environment will remain at: {temp_dir}")
        print("You can examine the results manually.")
        
    except Exception as e:
        print(f"Error during testing: {e}")
        # Clean up on error
        shutil.rmtree(temp_dir, ignore_errors=True)


if __name__ == "__main__":
    import json
    print("Adobe PDF CLI Tool Round 1B - Local Test")
    print("=" * 50)
    test_with_local_dirs()
