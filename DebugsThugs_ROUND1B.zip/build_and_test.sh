#!/bin/bash
# Adobe Round 1B - Build and Test Script

echo "=== Adobe PDF CLI Tool - Round 1B Build Script ==="
echo

# Build Docker image
echo "Building Docker image..."
docker build -t adobe-pdf-cli-round1b .

if [ $? -eq 0 ]; then
    echo "✅ Docker image built successfully!"
    echo
    
    # Create test directories
    echo "Creating test directories..."
    mkdir -p test_input test_output
    
    # Create sample persona.txt
    echo "A data scientist interested in machine learning algorithms, statistical analysis, and artificial intelligence applications in business." > test_input/persona.txt
    
    echo "✅ Test environment ready!"
    echo
    echo "📁 Directory structure:"
    echo "  test_input/  - Place your PDF files here"
    echo "  test_input/persona.txt - Sample persona created"
    echo "  test_output/ - Results will appear here"
    echo
    echo "🚀 To run the tool:"
    echo "  docker run -v \$(pwd)/test_input:/app/input -v \$(pwd)/test_output:/app/output adobe-pdf-cli-round1b"
    echo
else
    echo "❌ Docker build failed. Check the error messages above."
    exit 1
fi
